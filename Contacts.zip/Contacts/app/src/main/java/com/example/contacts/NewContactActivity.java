package com.example.contacts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.room.Database;
import androidx.room.Room;

import com.example.contacts.database.AppDatabase;
import com.example.contacts.models.Contact;
import com.example.contacts.presenter.BaseMVPView;
import com.example.contacts.presenter.ContactPresenter;
import com.example.contacts.presenter.NewContactPresenter;

import java.util.ArrayList;

public class NewContactActivity extends BaseActivity implements NewContactPresenter.MVPView {
    NewContactPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        presenter = new NewContactPresenter(this);

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);

        AppCompatTextView nameTextView = new AppCompatTextView(this);
        AppCompatEditText nameEditText = new AppCompatEditText(this);
        nameTextView.setText("Name");

        AppCompatTextView phoneNumberTextView = new AppCompatTextView(this);
        AppCompatEditText phoneNumberEditText = new AppCompatEditText(this);
        phoneNumberTextView.setText("Phone Number");

        AppCompatTextView emailTextView = new AppCompatTextView(this);
        AppCompatEditText emailEditText = new AppCompatEditText(this);
        emailTextView.setText("Email");

        AppCompatButton saveButton = new AppCompatButton(this);
        saveButton.setText("Save Contact");
        saveButton.setOnClickListener(view -> {
            presenter.createContact(
                    nameEditText.getText().toString(),
                    phoneNumberEditText.getText().toString(),
                    emailEditText.getText().toString());
        });

        mainLayout.addView(nameTextView);
        mainLayout.addView(nameEditText);
        mainLayout.addView(phoneNumberTextView);
        mainLayout.addView(phoneNumberEditText);
        mainLayout.addView(emailTextView);
        mainLayout.addView(emailEditText);
        mainLayout.addView(saveButton);
        setContentView(mainLayout);
    }

    @Override
    public void goBackToContactsPage(Contact contact) {
        Intent intent = new Intent();
        intent.putExtra("result", contact);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    @Override
    public void goBackToContactsPage() {
        Intent intent = new Intent();
        setResult(Activity.RESULT_CANCELED, intent);
        finish();
    }
}


