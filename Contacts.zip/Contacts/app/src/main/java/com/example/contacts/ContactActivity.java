package com.example.contacts;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

import com.example.contacts.models.Contact;
import com.example.contacts.presenter.ContactPresenter;

public class ContactActivity extends BaseActivity implements ContactPresenter.MVPView{
    ContactPresenter presenter;
    LinearLayout mainLayout;
    int ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        presenter = new ContactPresenter(this);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);

        Intent intent = getIntent();
        ID = intent.getIntExtra("contactID", 0);

        presenter.displayContact(ID);

        setContentView(mainLayout);
    }

    @Override
    public void renderContact(Contact contact) {
        AppCompatTextView nameTextView = new AppCompatTextView(this);
        nameTextView.setGravity(Gravity.CENTER);
        nameTextView.setTextSize(40);
        nameTextView.setText(contact.name);

        AppCompatTextView phoneNumberTextView = new AppCompatTextView(this);
        phoneNumberTextView.setTextSize(30);
        phoneNumberTextView.setText("Call: " + contact.phoneNumber);

        AppCompatTextView emailTextView = new AppCompatTextView(this);
        emailTextView.setTextSize(30);
        emailTextView.setText("Email: " + contact.email);

        mainLayout.addView(nameTextView);
        mainLayout.addView(phoneNumberTextView);
        mainLayout.addView(emailTextView);
    }
}
