package com.example.contacts.presenter;

import com.example.contacts.database.AppDatabase;
import com.example.contacts.models.Contact;

public class ContactPresenter {
    ContactPresenter.MVPView view;
    AppDatabase database;

    public interface MVPView extends BaseMVPView {
        public void renderContact(Contact contact);
    }

    public ContactPresenter(MVPView view){
        this.view = view;
        database = view.getContextDatabase();
    }

    public void displayContact(int ID){
        new Thread(() -> {
            Contact contact = database.getContactDao().getContact(ID);
            view.renderContact(contact);
        }).start();

    }
}
