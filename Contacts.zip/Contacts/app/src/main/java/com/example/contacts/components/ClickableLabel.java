package com.example.contacts.components;

import android.content.Context;
import android.widget.LinearLayout;

import androidx.appcompat.widget.AppCompatTextView;

import com.example.contacts.models.Contact;

public class ClickableLabel extends LinearLayout {

    public interface OnClick{
        public void call();
    }

    public ClickableLabel(Context context, Contact contact, OnClick onClick){
        super(context);

        AppCompatTextView nameTextView = new AppCompatTextView(context);
        nameTextView.setText(contact.name);
        nameTextView.setTextSize(30);
        nameTextView.setPadding(30,5,30,5);
        nameTextView.setOnClickListener(view -> {
            onClick.call();
        });

        addView(nameTextView);

    }
}
