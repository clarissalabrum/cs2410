package com.example.contacts.presenter;

import com.example.contacts.database.AppDatabase;
import com.example.contacts.models.Contact;

public class NewContactPresenter {
    MVPView view;
    AppDatabase database;

    public interface MVPView extends BaseMVPView {
        public void goBackToContactsPage(Contact contact);
        public void goBackToContactsPage();
    }

    public NewContactPresenter(MVPView view){
        this.view = view;
        database = view.getContextDatabase();
    }

    public void createContact(String name, String phoneNumber, String email){
        if (name == null || name.equals("")){
            view.goBackToContactsPage();
        }
        if (phoneNumber == null || phoneNumber.equals("")){
            phoneNumber = "Not Listed";
        }
        if (email == null || email.equals("")){
            email = "Not Listed";
        }
        String finalPhoneNumber = phoneNumber;
        String finalEmail = email;

        new Thread(() -> {
            Contact contact = new Contact();
            contact.name = name;
            contact.phoneNumber = finalPhoneNumber;
            contact.email = finalEmail;
            contact.id = (int) database.getContactDao().insert(contact);
            view.goBackToContactsPage(contact);
        }).start();
    }
}
