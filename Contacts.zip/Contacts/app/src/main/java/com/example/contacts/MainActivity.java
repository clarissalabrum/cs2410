package com.example.contacts;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.example.contacts.components.ClickableLabel;
import com.example.contacts.models.Contact;
import com.example.contacts.presenter.ContactsPresenter;

public class MainActivity extends BaseActivity implements ContactsPresenter.MVPView {
    private final int CREATE_NEW_CONTACT = 1;
    ContactsPresenter presenter;
    LinearLayout mainLayout;
    LinearLayout contactsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        presenter = new ContactsPresenter(this);
        mainLayout = new LinearLayout(this);
        contactsLayout = new LinearLayout(this);
        ScrollView scrollView = new ScrollView(this);

        mainLayout.setOrientation(LinearLayout.VERTICAL);
        contactsLayout.setOrientation(LinearLayout.VERTICAL);

        AppCompatButton createContactButton = new AppCompatButton(this);
        createContactButton.setText("Create New Contact");
        createContactButton.setOnClickListener(view -> {
            presenter.goToNewContactsPage();
        });

        mainLayout.addView(createContactButton);
        mainLayout.addView(contactsLayout);
        scrollView.addView(mainLayout);

        setContentView(scrollView);
    }

    @Override
    public void renderContact(Contact contact) {
        runOnUiThread(() -> {
            ClickableLabel clickableLabel = new ClickableLabel(
                    this,
                    contact,
                    () -> {
                        presenter.goToContactPage(contact);
                    });
            contactsLayout.addView(clickableLabel);
        });
    }

    @Override
    public void goToNewContactsPage() {
        Intent intent = new Intent(this, NewContactActivity.class);
        startActivityForResult(intent, CREATE_NEW_CONTACT);
    }

    @Override
    public void goToContactPage(Contact contact) {
        Intent intent = new Intent(this, ContactActivity.class);
        intent.putExtra("contactID", contact.id);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_NEW_CONTACT && resultCode == Activity.RESULT_OK){
            Contact contact = (Contact) data.getSerializableExtra("result");
            presenter.onNewContactCreated(contact);
        }
    }
}