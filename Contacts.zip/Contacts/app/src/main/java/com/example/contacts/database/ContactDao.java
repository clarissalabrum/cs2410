package com.example.contacts.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.contacts.models.Contact;

import java.util.List;

@Dao
public interface ContactDao {
    @Query("SELECT * FROM contact")
    List<Contact> getAllContacts();

    @Insert
    long insert(Contact contact);

    @Query("SELECT * FROM contact WHERE id LIKE :ID")
    Contact getContact(int ID);
}
